#!/bin/sh
rm -f */a.out
rm -f */parser.out
rm -f */parsetab.py
rm -rf */__pycache__
